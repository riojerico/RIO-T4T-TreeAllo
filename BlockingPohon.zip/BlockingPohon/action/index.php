<?php 
header("location:../");
?>