<?php
	//include 'assets/lib-encript/function.php';

	header("location:login")

?>